<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use  Symfony\Component\HttpFoundation\Response ;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Event ;

class EventController extends AbstractController
{
    /**
     * @Route("/create", name="createAction")
     */
   public function createAction(Request $request)
   {  
       
        // you can fetch the EntityManager via $this->getDoctrine()
       // or you can add an argument to your action: createAction(EntityManagerInterface $em)

       $event = new  Event(); // here we will create an object from our class Product.

       $form = $this->createFormBuilder($event)->add('Name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Date', DateTimeType::class, array('attr' => array('class'=> 'form-control d-flex', 'style'=>'margin-bottom:15px')))
       ->add('Description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Email', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Phone', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('URL', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Type', ChoiceType::class, array('choices'=>array('Music'=>'music', 'Theater'=>'theater', 'Sport'=>'sport', 'Movies'=>'movies'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	   ->add('Save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-outline-primary', 'style'=>'margin-bottom:15px; margin-top:15px')))
       ->getForm();
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){

       	   $name = $form['Name']->getData();
           $date = $form['Date']->getData();
           $description = $form['Description']->getData();
           $image = $form['Image']->getData();
           $capacity = $form['Capacity']->getData();
           $email = $form['Email']->getData();
           $phone = $form['Phone']->getData();
           $address = $form['Address']->getData();
           $URL = $form['URL']->getData();
           $type = $form['Type']->getData();

       $event->setName($name); // in our Product class we have a set function for each column in our db
       $event->setDate($date);
       $event->setDescription($description);
       $event->setImage($image);
       $event->setCapacity($capacity);
       $event->setEmail($email);
       $event->setPhone($phone);
       $event->setAddress($address);
       $event->setURL($URL);
       $event->setType($type);

       // tells Doctrine you want to (eventually) save the Product (no queries yet)
       $em = $this->getDoctrine()->getManager();
       $em->persist($event);
       $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );       
       return $this->redirectToRoute('home_page');
   }
   return $this->render('event/create.html.twig', array('form' => $form->createView()));
   }

       /**
    * @Route("/details/{eventId}", name="detailsAction")
    */ 
     public function showdetailsAction($eventId)
    {
        $event = $this->getDoctrine()
            ->getRepository(Event::class)
            ->find($eventId);
         if (!$event) {
            throw  $this->createNotFoundException(
                 'No event found for id '.$eventId
            );
        } else {
                 return $this->render("event/index.html.twig",array("event"=>$event));
        }

}

       /**
    * @Route("/", name="home_page")
    */ 
    public function index()
    {
        $events = $this->getDoctrine()
            ->getRepository(Event::class)
            ->findAll();

            return $this->render("event/home.html.twig",array("events"=>$events));
        

}

       /**
    * @Route("/{filter}", name="filter_page")
    */ 
    public function filter($filter)
    {
        $events = $this->getDoctrine()->getRepository(Event::class)->findBy(['type' => $filter]);

            return $this->render("event/home.html.twig",array("events"=>$events));
        

}


       /**
    * @Route("/delete/{eventId}", name="deleteAction")
    */ 
	public function deleteAction($eventId)
	{
		   $em = $this->getDoctrine()->getManager();
           $event = $this->getDoctrine()->getRepository('App:Event')->find($eventId);
           $em->remove($event);
            $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Removed'
                   );
            return $this->redirectToRoute('home_page');
}
       /**
    * @Route("/edit/{eventId}", name="editAction")
    */ 
	public function editAction($eventId, Request $request)
	{

		$event = $this->getDoctrine()->getRepository(Event::class)->find($eventId);

       $event->setName($event->getName());
       $event->setDate($event->getDate());
       $event->setDescription($event->getDescription());
       $event->setImage($event->getImage());
       $event->setCapacity($event->getCapacity());
       $event->setEmail($event->getEmail());
       $event->setPhone($event->getPhone());
       $event->setAddress($event->getAddress());
       $event->setURL($event->getURL());
       $event->setType($event->getType());

       $form = $this->createFormBuilder($event)->add('Name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Date', DateTimeType::class, array('attr' => array('class'=> 'form-control d-flex', 'style'=>'margin-bottom:15px')))
       ->add('Description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Email', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Phone', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('URL', TextType::class, array('required'=> false, 'attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('Type', ChoiceType::class, array('choices'=>array('Music'=>'music', 'Theater'=>'theater', 'Sport'=>'sport', 'Movies'=>'movies'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	   ->add('Save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn btn-outline-primary', 'style'=>'margin-bottom:15px; margin-top:15px')))
       ->getForm();
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){

       	   $name = $form['Name']->getData();
           $date = $form['Date']->getData();
           $description = $form['Description']->getData();
           $image = $form['Image']->getData();
           $capacity = $form['Capacity']->getData();
           $email = $form['Email']->getData();
           $phone = $form['Phone']->getData();
           $address = $form['Address']->getData();
           $URL = $form['URL']->getData();
           $type = $form['Type']->getData();

           $em = $this->getDoctrine()->getManager();
           $event = $em->getRepository('App:Event')->find($eventId);

       $event->setName($name);
       $event->setDate($date);
       $event->setDescription($description);
       $event->setImage($image);
       $event->setCapacity($capacity);
       $event->setEmail($email);
       $event->setPhone($phone);
       $event->setAddress($address);
       $event->setURL($URL);
       $event->setType($type);

       $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Updated'
                   );       
       return $this->redirectToRoute('home_page');
   }
   return $this->render('event/edit.html.twig', array('event' => $event, 'form'=> $form->createView()));
   }

}